# Import libraries.
import sys
sys.path.append("./packages")
import onnxruntime as rt
import numpy as np

# This needs to be installed on the machine
from PIL import Image

from datetime import datetime

import boto3

def lambda_handler(event, context):
    
    # Download test image and model from s3.
    client = boto3.client('s3')
    client.download_file('handwriting-recog-aws-bucket', 'digit.png', '/tmp/digit.png')
    client.download_file('handwriting-recog-aws-bucket', 'model.onnx', '/tmp/model.onnx')
    
    # Download image and model to disk.
    
    # from PilLite import Image
    img = Image.open('/tmp/digit.png')
    new_img = img.resize((28, 28), Image.BICUBIC)
    new_img.save('/tmp/s_digit.png', quality=100)
    
    # Preprocessing of the image.
    new_img = Image.open('/tmp/s_digit.png').convert("L")
    new_img = np.asarray(new_img).astype("float32")
    new_img /= 256
    
    #print(new_img)
    new_img = new_img.reshape(-1,1,28,28)
    #print(new_img)
    
    # Create session.
    sess = rt.InferenceSession("/tmp/model.onnx")
    input_name = sess.get_inputs()[0].name
    output_name = sess.get_outputs()[0].name
    pred_onx = sess.run([output_name], {input_name: new_img})[0]
    print(pred_onx)
    
    from scipy.special import softmax
    result = np.array(pred_onx).tolist()
    #print(result)
    scores = softmax(result[0], axis=0)
    scores = np.squeeze(scores)
    # print(np.argmax(scores))
    print(scores)
    
    a = np.argsort(scores)[::-1]
    print(a)
    nums = [0,1,2,3,4,5,6,7,8,9]

    # Start creating output file.
    f = open("/tmp/results.txt","w+")

    for i in a[0:10]:
    	# print('class=%s ; probability=%f' %(nums[i],scores[i]))
        f.write('class=%s ; probability=%f \n' %(nums[i],scores[i]))
    f.close()

    # Get today's date and append to the file name.
    current_date_time = str(datetime.now())
    # Upload the created file to the s3 bucket.
    client.upload_file('/tmp/results.txt', 'handwriting-recog-aws-bucket', 'results.txt')




